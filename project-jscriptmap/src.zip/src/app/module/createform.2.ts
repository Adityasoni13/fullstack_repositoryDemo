// export class createform {

//     textprop: string;
//     emailprop: string;
//     addressprop: string;
//     locprop: string;
//     latitudeprop: string;
//     longitudeprop: string;

// }

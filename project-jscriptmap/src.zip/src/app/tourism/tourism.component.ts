import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tourism',
  templateUrl: './tourism.component.html',
  styleUrls: ['./tourism.component.css']
})
export class TourismComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
